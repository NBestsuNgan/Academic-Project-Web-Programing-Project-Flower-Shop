<?php
    $db = mysqli_connect("localhost","root","",);
    mysqli_select_db($db,"Flowershop");
    mysqli_query($db,"SET NAMES 'utf8' COLLATE 'utf8_general_ci';"); 
?>