<?php  include 'connection.php'   ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    
    </head>
    <body class="sb-nav-fixed">
       
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">


                        <div class="card mb-4 mt-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Detail Information of Order
                            </div>
                            <div>
                                <br>        
                                <a href="report_order.php"> <button type="button" class="btn btn-outline-dark"> Back </button> </a>
                                <right> <a style="text-align:right" href = "../login.php"> <button type="button" class="btn btn-secondary"> Login </button> </a> </right>
                            </div>

                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>OrderID</th>
                                            <th>Flower Name</th>
                                            <th>Price</th>
                                            <th>Amount</th>
                                            <th>Total Price</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>od_id</th>
                                            <th>flo_name</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
<?php
$ids = $_GET['id'];
$sql = "SELECT od.od_id, f.flo_name, od.orderPrice, od.orderQty, od.Total 
FROM order_detail as od, record as rec, flower as f 
WHERE f.flo_id = od.flo_id 
AND od.rec_id = rec.rec_id
AND rec.rec_id = '$ids'";
$result = mysqli_query($db,$sql);
while($row=mysqli_fetch_array($result)){
?>
                                    
                                        <tr>
                                            <td> <?=$row['od_id']?> </td>
                                            <td> <?=$row['flo_name']?> </td>
                                            <td> <?=$row['orderPrice']?> </td>
                                            <td> <?=$row['orderQty']?> </td>
                                            <td> <?=$row['Total']?> </td>
                                            
                                        </tr>
                                    
                                    <?php 
                                    }
                                    mysqli_close($db); 
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>

                <?php  include "footer.php"; ?>

            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>