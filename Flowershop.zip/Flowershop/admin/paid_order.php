<?php
include "connection.php";

$ids = $_GET['id'];
$query = "UPDATE record SET order_status = 2 WHERE rec_id = '$ids'";
$result = mysqli_query($db,$query);
if($result){
    echo "<script>window.location='report_order.php'; </script>";
}else{
    echo "<script>alert('cannot delete order'); </script>";
}

mysqli_close($db);





?>