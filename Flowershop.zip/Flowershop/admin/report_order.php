<?php  include 'connection.php'   ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    
    </head>
    <body class="sb-nav-fixed">
       
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">


                        <div class="card mb-4 mt-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Record Order
                            </div>
                            <div>
                                <br>
                                <a href="paid_page.php"> <button type="button" class="btn btn-outline-success"> Paided </button> </a>
                                <a href="unpaid_page.php"> <button type="button" class="btn btn-outline-warning"> UnPaided </button> </a>
                                <a href="cancel_page.php"> <button type="button" class="btn btn-outline-danger"> Canceled </button> </a>              
                                <a href="report_order.php"> <button type="button" class="btn btn-outline-dark"> Default </button> </a> 
                                <right> <a style="text-align:right" href = "../login.php"> <button type="button" class="btn btn-secondary"> Login </button> </a> </right>
                            </div>

                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>OrderID</th>
                                            <th>Customer</th>
                                            <th>Address</th>
                                            <th>Tel</th>
                                            <th>Total Price</th>
                                            <th>Date</th>
                                            <th>Purchase Status</th>
                                            <th>Change Paid Order</th>
                                            <th>Change Unpaid Order</th>
                                            <th>Change Cancel Order</th>
                                            <th> Info </th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>rec_id</th>
                                            <th>cus_name</th>
                                            <th>destination</th>
                                            <th>tel</th>
                                            
                                        </tr>
                                    </tfoot>
                                    <tbody>
<?php
$sql = "SELECT * FROM record ORDER BY reg_date DESC";
$result = mysqli_query($db,$sql);
while($row=mysqli_fetch_array($result)){
$status = $row['order_status'];
?>
                                    
                                        <tr>
                                            <td> <?=$row['rec_id']?> </td>
                                            <td> <?=$row['cus_name']?> </td>
                                            <td> <?=$row['destination']?> </td>
                                            <td> <?=$row['tel']?> </td>
                                            <td> <?=$row['total_price']?> </td>
                                            <td> <?=$row['reg_date']?> </td>
                                            <td>
                                            <?php
                                            if($status == 1){
                                                echo "<b style='color:orange'> UnPaid </b>";
                                            }else if($status == 2){
                                                echo "<b style='color:green'> Paid </b>";
                                            }else if($status == 0){
                                                echo "<b style='color:red'> Cancel Order </b>";
                                            }
                                            ?>
                                            </td>
                                            <td> <a href = "paid_order.php?id=<?=$row['rec_id']?>" class="btn btn-success" onclick="del(this.href); return false;"> Pained </button> </a> </td>
                                            <td> <a href = "unpaid_order.php?id=<?=$row['rec_id']?>" class="btn btn-warning" onclick="del(this.href); return false;"> Unpaided </button> </a> </td>
                                            <td> <a href = "cancel_order.php?id=<?=$row['rec_id']?>" class="btn btn-danger" onclick="del(this.href); return false;"> Cancle </button> </a> </td>
                                            <td> <a href = "info.php?id=<?=$row['rec_id']?>" class="btn btn-info" > Info </button> </a> </td>
                                        </tr>
                                    
                                    <?php 
                                    }
                                    //mysqli_close($db); 
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>

                <?php  include "footer.php"; ?>

            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
<script>
function del(mypage){
    var agree=confirm('Are you sure about that!');
    if(agree){
        window.location=mypage;
    }
}   
</script>