<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cart</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" >
    <script src="bootstrap/js/bootstrap.bundle.min.js" ></script>
</head>
<body>
    <div class="container">
        <form id="form1" method = "POST" action="confrim_order.php">
        <div class = "row">
            <div class = "col-md-10">
                <table class = "table table-hover">
                    <tr>  
                        <th> Order </th>
                        <th> Name </th>
                        <th> Price </th>
                        <th> Amount </th>
                        <th> Total </th>
                        <th> Change </th>
                        <th> Delete </th>
                    </tr>
<?php
    include 'menu.php'; 
    session_start();
    include "connection.php";
    $total = 0;
    $sumprice = 0;
    $m = 1;
for ($i=0;$i <= (int)$_SESSION["intLine"]; $i++){
    if(($_SESSION["strProductID"][$i]) != ""){
    $query = "SELECT * from flower WHERE flo_id = '".$_SESSION["strProductID"][$i]."' ";
    $result = mysqli_query($db,$query);
    $row_pro = mysqli_fetch_array($result);
    
    $_SESSION["price"] = $row_pro['flo_price'];
    $total = $_SESSION["strQty"][$i];
    $sum = $total * $row_pro['flo_price'];
    $sumprice = (float)$sumprice + $sum;
    $_SESSION['$sumprice'] = $sumprice;
?>
    <tr>
    <td> <?=$m?> </td>
    <td> 
        <img src="image/<?=$row_pro['flo_url']?>" width = "80" height = "100"> <?=$row_pro['flo_name']?> 
    </td>
    <td> <?=$row_pro['flo_price']?> </td>
    <td> <?=$_SESSION["strQty"][$i]?> </td>
    <td> <?=$sum?> </td>
    <td> 
    <a href="order.php?id=<?=$row_pro['flo_id']?>" class="btn btn-outline-dark">+</a>   
    <?php if($_SESSION["strQty"][$i] > 1){   ?>
    <a href="order_del.php?id=<?=$row_pro['flo_id']?>" class="btn btn-outline-dark">-</a> 
    <?php } ?>
    </td>
    <td><a href = "delete.php?Line=<?=$i?>"> <img src="image/delete.png" width = "30" > </a> </td>
    </tr>
<?php
    $m = $m + 1;
    }
}
?>
<tr>
<td class="text-end" colspan="4"> Total Price <td>
<td class="text-center"> <?=$sumprice?> <td>
<td> Bath <td>
</tr>
</table>



<a href = "customer_mainpage.php"> <button type="button" class="btn btn-secondary">Chose Product</button> </a>
<div style="text-align:right"> <button type="submit" class="btn btn-secondary">Confrim Order</button>
</div>
</div>
<br><br>
<div class="row">
    <div class="col-md-4">
    <div class="alert alert-success" h4 role="alert">
    Customer detail
    </div>
    Full Name:
    <input type = "text" name= "cus_name" class = "form-control" placeholder="Full Name ..." required> 
    Address:
    <textarea class="form-control" placeholder="Address ..." name = "cus_add" rows = "3" required> </textarea>
    Tel:
    <input type = "text" name= "cus_tel" class = "form-control" placeholder="Tel ..." required>
    <br><br><br>
    </div>
  </div>
</form>

</div>
</body>
</html>


