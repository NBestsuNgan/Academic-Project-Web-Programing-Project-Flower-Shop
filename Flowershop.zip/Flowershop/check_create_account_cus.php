<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    require("connection.php");

    $account_username=$_GET['account_username'];
    $account_pass=$_GET['account_pass'];
    $account_pass1=$_GET['account_pass1'];
    $account_name=$_GET['name'];
    $account_surname=$_GET['surname'];
    $account_date=$_GET['date'];
    $account_address=$_GET['address'];
    $account_tel=$_GET['tel'];

    if($account_pass!=$account_pass1){
        header("refresh: 0; url=create_account_reject_pass_cus.php");
    }
    else{
        $query="SELECT * FROM customer  WHERE cus_username ='$account_username' ";
        $result=mysqli_query($db,$query);
        $list=mysqli_fetch_array($result);
        if($list){
            if($account_username === $list['cus_username']){
                header("refresh: 0; url=create_account_reject_duplicate_cus.php");
            }
        }
        else {
            $query="INSERT INTO customer (cus_username,cus_pass,cus_name,cus_surname,cus_date,cus_address,cus_tel)
            VALUES ('$account_username','$account_pass','$account_name','$account_surname','$account_date'
            ,'$account_address','$account_tel');";
            mysqli_query($db,$query);
            header("refresh: 0; url=login.php");
        }
    }
    ?>
</body>
</html>


