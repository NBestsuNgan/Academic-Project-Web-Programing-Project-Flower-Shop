<?php
    require("connection.php");

    $account_username=$_GET['account_username'];
    $account_pass=$_GET['account_pass'];
    $account_pass1=$_GET['account_pass1'];
    $account_tag_name=$_GET['tag_name'];
    $account_tel=$_GET['tel'];
    $account_license=$_GET['license'];
    $check_license = array("A110301","A110302","B110311","C110321");

    if(!in_array($account_license,$check_license)){
        header("refresh: 0; url=create_account_license_check.php");
    }
    else if($account_pass!=$account_pass1){
        header("refresh: 0; url=create_account_reject_pass_sup.php");
    }
    else{
        $query="SELECT * FROM supplier  WHERE sup_username ='$account_username' ";
        $result=mysqli_query($db,$query);
        $list=mysqli_fetch_array($result);
        if($list){
            if($account_username === $list['sup_username']){
                header("refresh: 0; url=create_account_reject_duplicate_sup.php");
            }
        }
        else {
            $query="INSERT INTO supplier (sup_username,sup_pass,sup_tag,sup_tel)
            VALUES ('$account_username','$account_pass','$account_tag_name','$account_tel');";
            mysqli_query($db,$query);
            header("refresh: 0; url=login.php");
        }
    }
    ?>