<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" >
    <script src="bootstrap/js/bootstrap.bundle.min.js" ></script>
</head>
<body>
    
<?php
session_start();
include "connection.php";
$cusname = $_POST['cus_name'];
$cusadd = $_POST['cus_add'];
$custell = $_POST['cus_tel'];

$query = "INSERT INTO record(cus_name, destination, tel, total_price, order_status) 
          VALUES ('$cusname','$cusadd','$custell','" .$_SESSION['$sumprice']."','1')";
mysqli_query($db,$query);

$orderID = mysqli_insert_id($db);

for ($i=0;$i <= (int)$_SESSION["intLine"]; $i++){
    if(($_SESSION["strProductID"][$i]) != ""){
        // pull information product
        $sql = "SELECT * FROM flower WHERE flo_id = '" .$_SESSION["strProductID"][$i]. "'";
        $result=mysqli_query($db,$sql);
        $row=mysqli_fetch_array($result);
        $price = $row['flo_price'];
        $total= $_SESSION["strQty"][$i] * $price;

        $sql2 = "INSERT INTO order_detail(rec_id,flo_id,orderPrice,orderQty,Total) 
        VALUES('$orderID','" .$_SESSION["strProductID"][$i]. "','$price','" .$_SESSION["strQty"][$i]. "'
        ,'$total' )";
        if(mysqli_query($db,$sql2)){
            // update stock product
            $sql3 = "UPDATE flower SET flo_amount = flo_amount - '" .$_SESSION["strQty"][$i]. "'
            WHERE flo_id = '" .$_SESSION["strProductID"][$i]. "' ";
            mysqli_query($db,$sql3);
            echo "<script> alert('Upload Success fully') </script>";
            //echo "<script> window.location='customer_mainpage.php'; </script>";
        }
    }
}
mysqli_close($db);
unset($_SESSION['intLine']);
unset($_SESSION['strProductID']);
unset($_SESSION['strQty']);
unset($_SESSION['$sumprice']);
session_destroy();
?>
<center><img src="image/payment.jpg" width = "350" height = "350"></center>
<center> Overdue : <span class="text-danger">  <?=$total?> </span> </center>
<br> <center><a href = "customer_mainpage.php"> <button type="button" class="btn btn-success">Buy More</button> </a></center>


</body>
</html>