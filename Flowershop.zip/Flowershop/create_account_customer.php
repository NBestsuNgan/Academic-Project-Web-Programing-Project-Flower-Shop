<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<FORM METHOD=GET ACTION="check_create_account_cus.php">
    <h3> Customer </h3>
    Username : <input type="text" name="account_username">
	<br>
	Password : <input type="text" name="account_pass">
	<br>
    Recheck Password <input type="text" name="account_pass1">
    <br>
    Name <input type="text" name="name">
    <br>
    Surname <input type="text" name="surname">
    <br>
    Date of Brith <input type="text" name="date">
    <br>
    Address <input type="text" name="address">
    <br>
    Tel <input type="text" name="tel">
    <br>
    <input type="submit"> <a href="select_account.php" > Back </a> 
</form>
</body>
</html>