<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2> Password not match!! Please Try again </h2>
    <?php
    header("refresh: 2; url=create_account_customer.php")
    ?>
</body>
</html>