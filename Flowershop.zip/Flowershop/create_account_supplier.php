<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<FORM METHOD=GET ACTION="check_create_account_sup.php">
    <h3> Supplier </h3>
    Username : <input type="text" name="account_username">
	<br>
	Password : <input type="text" name="account_pass">
	<br>
    Recheck Password <input type="text" name="account_pass1">
    <br>
    Tag Name <input type="text" name="tag_name">
    <br>
    Tel <input type="text" name="tel">
    <br>
    license <input type="text" name="license">
    <br>
    <input type="submit"> <a href="select_account.php" > Back </a> 
</form>
</body>
</html>