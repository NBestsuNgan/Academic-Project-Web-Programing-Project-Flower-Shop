<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>customer_main_page</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" >
    <script src="bootstrap/js/bootstrap.bundle.min.js" ></script>
</head>
<body>
    <?php include 'menu.php'; ?>
<FORM METHOD="GET" ACTION="order.php">
<?php require("connection.php")?>
<div class = "container">
<br>
    <div class = "row">
    <?php
        $query = "SELECT * from flower";
        $result = mysqli_query($db,$query);
    while($row = mysqli_fetch_array($result)){
    ?>
        <div class = "col-sm-3">
            <div class="text-center">
        <img src = "image/<?=$row['flo_url'] ?>" width="200px" height = "220" class="mt-5 p-2 my-2 border"> <br>
            <div class="alert alert-secondary" role="alert"> <?=$row['flo_name'] ?>  </div> 
            Suggest for <?=$row['flo_suggest'] ?> <br>
            Price <b  class="text-danger"> <?=$row['flo_price'] ?> </b>  Bath, Avaliable:<b class="text-danger"> <?=$row['flo_amount']?> </b> <br>
            <a class="btn btn-secondary mt-3" href="order.php?id=<?=$row['flo_id']?>" > Add to cart </a>

    </div>
    <br>
    </div>
    <?php
    }
    mysqli_close($db);
    ?>
</div>
</div>

</form>
</body>
</html>