<?php
echo "Wrong Username or Password. Please try again!";
header("refresh: 2; url=login.php");
?>
