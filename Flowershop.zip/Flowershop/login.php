<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" >
    <script src="bootstrap/js/bootstrap.bundle.min.js" ></script>
</head>

<body>
<FORM METHOD="GET" ACTION="login_handler.php">
  
	<p style="text-align:center;">Username : <input type="text" name="user_name"></p>
	<p style="text-align:center;">Password : <input type="text" name="user_pass"></p>
	<p style="text-align:center;"> <input type="submit"> Customer : <input type = "checkbox" name = "check_cus"> Suppliers : <input type = "checkbox" name = "check_sup"></p>
    <p style="text-align:center;"> Don't have an account? <a href="select_account.php">Create an account</a></p>
	
   
</form>
</body>
</html>