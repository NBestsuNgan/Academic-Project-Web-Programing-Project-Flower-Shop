<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" >
    <script src="bootstrap/js/bootstrap.bundle.min.js" ></script>
</head>
<body>

<?php

session_start();
require("connection.php");

$user_name=$_GET['user_name'];
$user_pass=$_GET['user_pass'];
if(($user_name == "admin") && ($user_pass == "admin")){
    header("location: admin/index.php");
}

if($_GET['check_cus']){
    $user_name=$_GET['user_name'];
    $user_pass=$_GET['user_pass'];
    $query="SELECT * FROM customer  WHERE cus_username='$user_name' AND cus_pass='$user_pass'";
    $result=mysqli_query($db,$query);
    $list=mysqli_fetch_array($result);
    if($list){
        header("refresh: 0; url=customer_mainpage.php");
    }
    else
    {
        header("refresh: 0; url=error.php");
    }
}
else if($_GET['check_sup']){
    $user_name=$_GET['user_name'];
    $user_pass=$_GET['user_pass'];
    $query="SELECT * FROM supplier  WHERE sup_username='$user_name' AND sup_pass='$user_pass'";
    $result=mysqli_query($db,$query);
    $list=mysqli_fetch_array($result);
    if($list){
    header("refresh: 0; url=supplier_mainpage.php");  
    }
    else
    {
        header("refresh: 0; url=error.php");
    }
}
else{
    header("refresh: 0; url=login.php");
}
?>
    

</body>
</html>