<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="Style.css">
    <script src="bootstrap/js/bootstrap.bundle.min.js" ></script>
</head>
<body>
<h2>Supplier Request</h2>
<div>
    <form method = "POST" action="supplier_request.php" enctype="multipart/form-data" > 
		<label for="Flower_Name">Flower Name:</label>
		<input type="text" id="Flower_Name" name="flo_name" required><br><br>
		
		<label for="Flower_Type">Flower Type:</label>
		<input type="text" id="Flower_Type" name="flo_type" required><br><br>
	
		<label for="Flower_Price">Flower Price:</label>
		<input type="float" id="Flower_Price" name="flo_price" required><br><br>

		<label for="Flower_Suggest">Flower Suggest:</label>
		<input type="text" id="Flower_Suggest" name="flo_sug" required><br><br>

		<label for="Flower_Amount">Flower Amount:</label>
		<input type="number" id="Flower_Amount" name="flo_amount" required><br><br>

		<label for="files">Select Photo:</label>
		<input type="file" name="file"><br><br>
		<div style="text-align:left"> <a href = "login.php"> <button type="button" class="btn btn-secondary">Back</button> </a> </div>
		<div style="text-align:right"><div> <button type="submit" name="submit" required>UPLOAD</button> </div>
	</form>
</div>
</body>
</html>