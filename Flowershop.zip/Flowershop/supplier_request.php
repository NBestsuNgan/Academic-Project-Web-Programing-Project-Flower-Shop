<?php
include "connection.php";

if(isset($_POST['submit'])){
    $flo_name = $_POST['flo_name'];
    $flo_type = $_POST['flo_type'];
    $flo_price = $_POST['flo_price'];
    $flo_sug = $_POST['flo_sug'];
    $flo_amount = $_POST['flo_amount'];
    $flo_url = $_FILES['file']['name'];

    $query = "INSERT INTO flower (flo_name, flo_type, flo_price, flo_suggest, flo_amount, flo_url) 
    VALUES ('$flo_name','$flo_type','$flo_price','$flo_sug','$flo_amount','$flo_url');";
    mysqli_query($db,$query);

    $file = $_FILES['file'];
    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg','jpeg','png','pdf');

    if(in_array($fileActualExt, $allowed)){
        if($fileError == 0){
            if($fileSize < 1000000){
                $fileNameNew = uniqid("",false).".".$fileActualExt;
                $fileDestination = "image/" .$fileName;
                move_uploaded_file($fileTmpName, $fileDestination );
                header("location: supplier_mainpage.php?uploadsuccess");
            }
            else{
                echo "Your file is too big!";
            }
        }
        else{
            echo "There was  an error uploading ypur file!";
        }
    }
    else{
       echo "You allow to upload file in jpg, jpeg, png, pdf!";
    }


}


?>